import { useCallback } from "react";
import { logout, loginUser, fetchUser } from "../features/auth/authSlice";
import { selectUser, selectToken, selectLoading, selectError, selectUserRole, selectAllUsers } from "../features/auth/authSelectors";

import { fetchAllUserData } from "../features/auth/authSlice";

import { useAppDispatch, useAppSelector } from "../app/hooks";

import type { AuthUser,LoginCredentials } from "../types/auth";

type LoginResult = {
  success: boolean;
  result: unknown;
};

type UseAuthReturn = {
  user: AuthUser | null;
  token: string | null;
  loading: boolean;
  error: string | null;
  role: string;
  isLoggedIn: boolean;
  isAdmin: boolean;
  allUsers: AuthUser[] | null;
  login: (credentials: LoginCredentials) => Promise<LoginResult>;
  logoutUser: () => void;
  fetchAllUsers: () => void;
};

function useAuth(): UseAuthReturn {
  const dispatch = useAppDispatch();

  const user = useAppSelector(selectUser);
  const token = useAppSelector(selectToken);
  const loading = useAppSelector(selectLoading);
  const error = useAppSelector(selectError);
  const role = useAppSelector(selectUserRole);
  const allUsers = useAppSelector(selectAllUsers);

  const login = useCallback(async (credentials: LoginCredentials): Promise<LoginResult> => {
      const result = await dispatch(loginUser(credentials));

      if (loginUser.fulfilled.match(result)) {
        await dispatch(fetchUser());
        return { success: true, result };
      }
      return { success: false, result };
    },
    [dispatch]
  );
  
  const logoutUser = useCallback(() => {
    dispatch(logout());
  }, [dispatch]);

  const fetchAllUsers = useCallback(() => {
    dispatch(fetchAllUserData());
  }, [dispatch]);

   return { user, token, loading, error, isLoggedIn: Boolean(token), logoutUser, login, role, isAdmin: role === "admin", 
      allUsers,fetchAllUsers
   };
}

export default useAuth;