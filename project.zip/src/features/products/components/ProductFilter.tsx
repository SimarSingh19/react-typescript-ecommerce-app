import { useEffect, useRef, useState } from "react";

import useDebounce from "../../../hooks/useDebounce";

type ProductFilterProps = {
  searchTerm: string;
  selectedCategory: string;
  categories: string[];
  onSearchChange: (value: string) => void;
  onCategoryChange: (value: string) => void;
  onClearFilters: () => void;
};

function ProductFilter({
  searchTerm,
  onSearchChange,
  selectedCategory,
  categories,
  onCategoryChange,
  onClearFilters}: ProductFilterProps) {
  
    const [localSearch, setLocalSearch] = useState<string>(searchTerm);
  
    const searchInputRef = useRef<HTMLInputElement | null>(null);
    const previousSearchRef = useRef<string>("");
    
    const debouncedSearch = useDebounce(localSearch, 500);

    useEffect(() => {
      previousSearchRef.current = searchTerm;

      onSearchChange(debouncedSearch);
    }, [debouncedSearch]);

    useEffect(() => {
      setLocalSearch(searchTerm);
    }, [searchTerm]);

    const handleClearFilters = () => {
      setLocalSearch("");

      // previousSearchRef.current = "";
      onClearFilters();

      searchInputRef.current?.focus();
    };

    useEffect(() => {
      searchInputRef.current?.focus();
    }, []);

    return (
    <div className="product_filter">
      <input
          ref={searchInputRef}
          type="text"
          placeholder="Search products..."
          value={localSearch}
          onChange={(e) => setLocalSearch(e.currentTarget.value)}/>

      <select value={selectedCategory}
        onChange={(e) => onCategoryChange(e.currentTarget.value)}>
        {categories.map((category) => (
          <option key={category} value={category}>
            {category}
          </option>
        ))}
      </select>
      <button className="app_btn app_btn_light" onClick={handleClearFilters}>Clear Filters</button>

      {searchTerm && (
        <p className="filter_info">Current Search: <strong>{searchTerm}</strong>
          {previousSearchRef.current && (
            <>
              {" "}
              | Previous Search:{" "}
              <strong>{previousSearchRef.current}</strong>
            </>
          )}
        </p>
      )}

    </div>
  );
}

export default ProductFilter;