import type { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import useAuth from "../hooks/useAuth"

type ProtectedRouteProps = {
  children: ReactNode;
};

function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isLoggedIn } = useAuth();

   if (!isLoggedIn) {
    return (<Navigate to="/" replace />);
  }
  
  return children;
}
export default ProtectedRoute;